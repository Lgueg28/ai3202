#This program computes a HMM for Intro To AI Homework 8 part 1

#Example Usage --> python hmmPart1.py typos20.data

